﻿using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MusicApi.Data;
using MusicApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MusicApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SongsDBController : ControllerBase
    {
        private ApiDbContext _context;
        public SongsDBController(ApiDbContext context)
        {
            _context = context;
        }

        // GET: api/<SongsDBController>
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return Ok(await _context.Songs.ToListAsync());
        }

        // GET api/<SongsDBController>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var song = await _context.Songs.FindAsync(id);
            if(song == null)
            {
                return NotFound("No Record was found against this ID");
            }
            else
            {
                return Ok(song);
            }
            //var song = _context.Songs.Find(id);
            //return song;
        }

        [HttpGet("[action]/{id}")]
        public int Test(int id)
        {
            return id;
        }

        // POST api/<SongsDBController>
        //[HttpPost]
        //public async Task<IActionResult> Post([FromBody] Song song)
        //{
        //    await _context.Songs.AddAsync(song);
        //    await _context.SaveChangesAsync();
        //    return StatusCode(StatusCodes.Status201Created);

        //    //_context.Songs.Add(song);
        //    //_context.SaveChanges();
        //}

        [HttpPost]
        public async Task<IActionResult> Post([FromForm] Song song)
        {
            
            string azureStorageAccConnectionString = @"DefaultEndpointsProtocol=https;AccountName=songscollection;AccountKey=7XCDv6r8znEdlrjA7s7VNZ8sp6ssZWRoQzZAdovSe9kSnD8rrJkaow/QhDxNogt6sil8pyzWZoE1+ASt86jjRg==;EndpointSuffix=core.windows.net";
            // files will be uploaded to this container in the storage acount.
            string containerName = "songscover";

            // it's purpose is to get reference to the container. We can now reference to the container with the following line
            BlobContainerClient blobContainerClient = new BlobContainerClient(azureStorageAccConnectionString, containerName);

            // need to send file to the container. Hence, we need the following client
            BlobClient blobClient = blobContainerClient.GetBlobClient(song.Image.FileName);

            // before sending the file, we need to read it in a memory stream
            var memoryStream = new MemoryStream();
            await song.Image.CopyToAsync(memoryStream);
            memoryStream.Position = 0;
            // finally upload the memeory stream to the azure blob 
            await blobClient.UploadAsync(memoryStream);

            // add the image url to the song
            song.ImageUrl = blobClient.Uri.AbsoluteUri;

            // add the song record in db
            await _context.Songs.AddAsync(song);
            _context.SaveChanges();
            return StatusCode(StatusCodes.Status201Created);







        }


        // PUT api/<SongsDBController>/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Song songObj)
        {
            Song? songToUpdate = await _context.Songs.FindAsync(id);
            songToUpdate.Title = songObj.Title;
            songToUpdate.Language = songObj.Language;
            songToUpdate.Duration = songObj.Duration;
            await _context.SaveChangesAsync();

            return Ok("Record updated sucessfully");
        }

        // DELETE api/<SongsDBController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
           var song =  await _context.Songs.FindAsync(id);
            if( song == null)
            {
                return NotFound("Record does not exist");
            }
            _context.Songs.Remove(song);
            await _context.SaveChangesAsync();
            return Ok("Record Deleted");
        }
    }
}
