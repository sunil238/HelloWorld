﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MusicApi.Data;
using MusicApi.Helper;
using MusicApi.Models;

namespace MusicApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistsController : ControllerBase
    {
        private ApiDbContext _dbContext;
        private IFileHelper _fileHelper;
         public ArtistsController(ApiDbContext dbContext, IFileHelper fileHelper)
        {
            _dbContext = dbContext;
            _fileHelper = fileHelper;
        }
       // [Authorize] // to allow only authenticated users to access the endpoint
        [HttpGet("[action]")]
        public async Task<IActionResult> GetArtists(int? pageNumber, int? pageSize)
        {
            int currentPageNumber = pageNumber ?? 1;
            int currentPageSize = pageSize ?? 5;
            
            var artists = await (from artist in _dbContext.Artists
                                 select new
                                 {
                                     Id = artist.Id,
                                     Name = artist.Name,
                                     Image = artist.ImageUrl
                                 }).ToListAsync();
                return Ok(artists.Skip((currentPageNumber - 1) * currentPageSize).Take(currentPageSize)); 
        }
      //  [Authorize]
        [HttpGet("[action]")]
        public async Task<IActionResult> ArtistDetails(int artistid)
        {
            var songs = await _dbContext.Artists.Where(a => a.Id == artistid).Include(a=>a.Songs).ToListAsync();
            return Ok(songs);
        }
        [HttpPost]
        public async Task<IActionResult> Post([FromForm] Artist artist)
        {
            // var imageUrl = await FileHelper.UploadImage(artist.Image);
            var imageUrl = await _fileHelper.UploadImage(artist.Image);
            artist.ImageUrl = imageUrl;

            await _dbContext.Artists.AddAsync(artist);
            await _dbContext.SaveChangesAsync();

            return StatusCode(StatusCodes.Status201Created);

        }
        
    }
}
