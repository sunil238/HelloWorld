﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MusicApi.Data;
using MusicApi.Helper;
using MusicApi.Models;

namespace MusicApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MusicController : ControllerBase
    {
        private ApiDbContext _dbContext;
        private IFileHelper _fileHelper;
        public MusicController(ApiDbContext dbContext, IFileHelper fileHelper)
        {
            _dbContext = dbContext;
            _fileHelper = fileHelper;
        }
        [HttpPost]
        public async Task<IActionResult> Post([FromForm] Song song)
        {
           // var imageUrl = await FileHelper.UploadImage(song.Image);
            var imageUrl = await _fileHelper.UploadImage(song.Image);
            song.ImageUrl = imageUrl;
            //  var audioUrl = await FileHelper.UploadFile(song.AudioFile);
            var audioUrl = await _fileHelper.UploadFile(song.AudioFile);
            song.AudioUrl = audioUrl;
            await _dbContext.Songs.AddAsync(song);
            await _dbContext.SaveChangesAsync();
            return StatusCode(StatusCodes.Status201Created);

        }

        [HttpGet("[action]")]
        public async Task<IActionResult> FeaturedSongs()
        {
            var songs = await (from s in _dbContext.Songs
                               where s.IsFeatured == true
                               select new
                               {
                                   Id = s.Id,
                                   Title = s.Title,
                                   Duration = s.Duration,
                                   ImageUrl = s.ImageUrl,
                                   AudioUrl = s.AudioUrl

                               }).ToListAsync();
            return Ok(songs);

        }
        [HttpGet("[action]")]
        public async Task<IActionResult> NewSongs()
        {
            var songs = await (from s in _dbContext.Songs
                               orderby s.UploadedDate descending
                               select new
                               {
                                   Id = s.Id,
                                   Title = s.Title,
                                   Duration = s.Duration,
                                   ImageUrl = s.ImageUrl,
                                   AudioUrl = s.AudioUrl
                               }).Take(15).ToListAsync();
            return Ok(songs);
        }

        [HttpGet("[action]")]
        public async Task<IActionResult> SearchSongs(string query)
        {
            var songs = await (from s in _dbContext.Songs
                               where s.Title.StartsWith(query)
                               select new
                               {
                                   Id = s.Id,
                                   Title = s.Title,
                                   Duration = s.Duration,
                                   ImageUrl = s.ImageUrl,
                                   AudioUrl = s.AudioUrl

                               }).Take(15).ToListAsync();
            return Ok(songs);
        }
    }
}
