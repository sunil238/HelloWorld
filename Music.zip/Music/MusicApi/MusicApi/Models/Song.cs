﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MusicApi.Models
{
    public class Song
    {
        //public int Id { get; set; }
        //[Required(ErrorMessage = "Title cannot be null or empty")]
        //public string Title { get; set; }
        //[Required(ErrorMessage ="Language should be provided")]
        //public string Language { get; set; }
        //[Required(ErrorMessage ="Kindly provide the duration")]
        //public string Duration { get; set; }

        public int Id { get; set; }
        public string Title { get; set; }
        public string Duration { get; set; }
        public DateTime UploadedDate { get; set; }
        public bool IsFeatured { get; set; }
        [NotMapped]
        public IFormFile Image { get; set; }
        // this property stores the image path in the database(actual Image is in Azure blob) 
        public string? ImageUrl { get; set; }
        [NotMapped]
        public IFormFile AudioFile { get; set; }
        public string AudioUrl { get; set; }
        public int ArtistId { get; set; }
        // Ading nullable type because it is possible that a Song does not belong to any album
        public int? AlbumId { get; set; }
    }
}
