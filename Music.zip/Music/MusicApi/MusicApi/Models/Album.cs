﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MusicApi.Models
{
    public class Album
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public int ArtistId { get; set; }
        [NotMapped]
        public IFormFile Image { get; set; }
        //  1 to Many relationship with Artist and Albums
        public ICollection<Song> Songs { get; set; }
    }
}
