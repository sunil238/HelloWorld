﻿namespace MusicApi
{
    public interface IFileHelper
    {
        Task<string> UploadImage(IFormFile file);

        Task<string> UploadFile(IFormFile audioFile);

    }
}
