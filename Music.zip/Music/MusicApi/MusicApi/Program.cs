using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using MusicApi;
using MusicApi.Data;
using MusicApi.Helper;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

//builder.Services.AddCors(options =>
//{

//    options.AddPolicy(name: "AllowOrigin",
//                      builder =>
//                      {
//                          builder.WithOrigins("http://songsbasket.azurewebsites.net", "https://songsbasket.azurewebsites.net/swagger/v1/swagger.json")
//                                              .AllowAnyHeader()
//                                              .AllowAnyMethod();
//                      });
//});
builder.Services.AddCors(); 

// Register the Swagger generator, defining 1 or more Swagger documents
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "My First RESTApi Project", Version = "v1" });
    c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.OAuth2,
        Flows = new OpenApiOAuthFlows
        {
            Implicit = new OpenApiOAuthFlow
            {
                AuthorizationUrl = new Uri("www.google.com", UriKind.Relative),
                Scopes = new Dictionary<string, string>
                            {
                                { "readAccess", "Access read operations" },
                                { "writeAccess", "Access write operations" }
                            }
            }
        }
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
           new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "oauth2"}

            },
            new[] {"readaccess","writeaccess"}
        }
    });
});

// Registration of dependency in the service container
builder.Services.AddTransient<IFileHelper, FileHelper>();

// http response can be shown in XML also using below method.
builder.Services.AddMvc().AddXmlSerializerFormatters();

// mention the db provider and connection string
//builder.Services.AddDbContext<ApiDbContext>(option => option.UseSqlServer(

//@"Data Source=(localdb)\ProjectModels;Initial Catalog=MusicDB;"));


// get connection string to appsettings.json file. - Azure SQL DB connection string
builder.Services.AddDbContext<ApiDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DbConnection")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    // app.UseSwaggerUI();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint(url: "/swagger/v1/swagger.json", name: "v1");
        //c.RoutePrefix = string.Empty;
        c.OAuthClientId("client-id");
        c.OAuthClientSecret("client-secret");
        c.OAuthRealm("client-realm");
        c.OAuthAppName("OAuth-app");
        c.OAuthUseBasicAuthenticationWithAccessCodeGrant();


    });
}
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint(url: "/swagger/v1/swagger.json", name: "v1");
    c.RoutePrefix = string.Empty;

});

app.UseDeveloperExceptionPage();

// checks if db is created or not. If not created creates one.
// If already exits then does nothing.
//using (var scope = app.Services.CreateScope())
//{
//    var dbContext = scope.ServiceProvider.GetRequiredService<ApiDbContext>();
//    // use context
//    dbContext.Database.EnsureCreated();
//}

app.UseHttpsRedirection();

app.UseRouting();

app.UseCors();
//app.UseCors("AllowOrigin");

app.UseAuthorization();

app.UseAuthentication();

app.MapControllers();

app.Run();
