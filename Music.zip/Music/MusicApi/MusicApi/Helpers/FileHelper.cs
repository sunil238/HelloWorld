﻿using Azure.Storage.Blobs;

namespace MusicApi.Helper
{
    public  class FileHelper : IFileHelper
    {
        public  async Task<string> UploadImage(IFormFile file)
        {
             string azureStorageAccConnectionString = @"DefaultEndpointsProtocol=https;AccountName=songscollection;AccountKey=7XCDv6r8znEdlrjA7s7VNZ8sp6ssZWRoQzZAdovSe9kSnD8rrJkaow/QhDxNogt6sil8pyzWZoE1+ASt86jjRg==;EndpointSuffix=core.windows.net";
            // files will be uploaded to this container in the storage acount.
            string containerName = "songscover";

            // it's purpose is to get reference to the container. We can now reference to the container with the following line
            BlobContainerClient blobContainerClient = new BlobContainerClient(azureStorageAccConnectionString, containerName);

            // need to send file to the container. Hence, we need the following client
            BlobClient blobClient = blobContainerClient.GetBlobClient(file.FileName);

            // before sending the file, we need to read it in a memory stream
            var memoryStream = new MemoryStream();
            await file.CopyToAsync(memoryStream);
            memoryStream.Position = 0;

            // finally upload the memeory stream to the azure blob 
            await blobClient.UploadAsync(memoryStream);
            return blobClient.Uri.AbsoluteUri;
        }

        public  async Task<string> UploadFile(IFormFile audioFile)
        {
            string azureStorageAccConnectionString = @"DefaultEndpointsProtocol=https;AccountName=songscollection;AccountKey=7XCDv6r8znEdlrjA7s7VNZ8sp6ssZWRoQzZAdovSe9kSnD8rrJkaow/QhDxNogt6sil8pyzWZoE1+ASt86jjRg==;EndpointSuffix=core.windows.net";
            // files will be uploaded to this container in the storage acount.
            string containerName = "audiofiles";

            // it's purpose is to get reference to the container. We can now reference to the container with the following line
            BlobContainerClient blobContainerClient = new BlobContainerClient(azureStorageAccConnectionString, containerName);

            // need to send file to the container. Hence, we need the following client
            BlobClient blobClient = blobContainerClient.GetBlobClient(audioFile.FileName);

            // before sending the file, we need to read it in a memory stream
            var memoryStream = new MemoryStream();
            await audioFile.CopyToAsync(memoryStream);
            memoryStream.Position = 0;

            // finally upload the memeory stream to the azure blob 
            await blobClient.UploadAsync(memoryStream);
            return blobClient.Uri.AbsoluteUri;
        }
    }
}
